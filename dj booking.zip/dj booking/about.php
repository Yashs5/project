<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">ગ્રીનટેક ડીજે સાઉન્ડ</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Services</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.php">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Contact</a>
        </li>
       
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>


<section class="my-5">
    <div class="py-5">
        <h3 class="text-center">About Us</h3>
    </div>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-6 col-md-6 col-12">
            <img src="images/ur11.jpg" height="500px" width="100%">
        </div>
        <div class="col-lg-6 col-md-6 col-12">
            <h2>I Am Urmish Rakholiya</h2>
            <p class="py-5">A FLOWER SHOP isIn physics, sound is a vibration that propagates
               as an acoustic wave through a transmission medium such as a gas, liquid or solid.
               In human physiology and psychology,
                sound is the reception of such waves and their perception by the brain.
               [1] Only acoustic waves that have frequencies lying between about 20 Hz and 20 kHz, 
               the audio frequency range, elicit an auditory percept in humans. 
               In air at atmospheric pressure, 
               these represent sound waves with
                wavelengths of 17 meters (56 ft) to 1.7 centimeters (0.67 in).
                Sound waves above 20 kHz are known as ultrasound and are not audible to humans. 
                Sound waves below
                 20 Hz are known as infrasound. Different animal species have varying hearing ranges..</p>
                <a href="about.php" class="btn btn-success">Check More...</a>
        </div>
    </div>
</div>
</section>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>