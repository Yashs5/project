<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>

    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">ગ્રીનટેક ડીજે સાઉન્ડ</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="service.php">Services</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.php">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="contact.php">Contact</a>
        </li>
        
       
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>


<div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/dj4.jpg" alt="Los Angeles" width="1100" height="500">
      <div class="carousel-caption">
        <h3>greentech</h3>
        <p>sound</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="images/dj1.jpg" alt="Chicago" width="1100" height="500">
      <div class="carousel-caption">
        <h3>greentech</h3>
        <p>sound</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="images/dj2.jpg" alt="New York" width="1100" height="500">
      <div class="carousel-caption">
        <h3>greentech</h3>
        <p>sound</p>
      </div>   
    </div>
  </div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>

<section class="my-5">
    <div class="py-5">
        <h3 class="text-center">About Us</h3>
    </div>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-6 col-md-6 col-12">
            <img src="images/ur11.jpg" height="500px" width="100%">
        </div>
        <div class="col-lg-6 col-md-6 col-12">
            <h2>I Am Urmish Rakholiya</h2>
            <p class="py-5">A sound isIn physics, sound is a vibration that propagates
               as an acoustic wave through a transmission medium such as a gas, liquid or solid.
               In human physiology and psychology,
                sound is the reception of such waves and their perception by the brain.
               [1] Only acoustic waves that have frequencies lying between about 20 Hz and 20 kHz, 
               the audio frequency range, elicit an auditory percept in humans. 
               In air at atmospheric pressure, 
               these represent sound waves with
                wavelengths of 17 meters (56 ft) to 1.7 centimeters (0.67 in).
                Sound waves above 20 kHz are known as ultrasound and are not audible to humans. 
                Sound waves below
                 20 Hz are known as infrasound. Different animal species have varying hearing ranges..</p>
                <a href="about.php" class="btn btn-success">Check More...</a>
        </div>
    </div>
</div>
</section>


<section class="my-5">
    <div class="py-5">
        <h3 class="text-center">Our Services</h3>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-12">
                <div class="card" height="90vh">
                    <img class="card-img-top" src="images/dj1.jpg" alt="Card image">
                     <div class="card-body">
                        <h4 class="card-title">DJ</h4>
                     <p class="card-text">( pronunciation (help·info) ) is a town
                        and municipality of Devbhumi Dwarka district in the state of Gujarat.
                        It is located on the western shore of ...</p>
                     <a href="#" class="btn btn-primary">See Profile</a>
                     </div>
                </div>
                </div>
            <div class="col-lg-4 col-md-4 col-12">
                <div class="card">
                    <img class="card-img-top" src="images/dj4.jpg" alt="Card image">
                     <div class="card-body">
                        <h4 class="card-title">DJ</h4>
                     <p class="card-text">, near Kullu town in Kullu district in
                        the Indian state of Himachal Pradesh. It is situated in the northern 
                        end of the Kullu Valley, ...</p>
                     <a href="#" class="btn btn-primary">See Profile</a>
                     </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-12">
                <div class="card">
                    <img class="card-img-top" src="images/dj5.jpg" alt="Card image">
                     <div class="card-body">
                        <h4 class="card-title">DJ</h4>
                     <p class="card-text"> also spelt as Hrishikesh, is a city
                        near Dehradun in Dehradun district of the Indian state Uttarakhand.
                        It is situated on the right bank of the ...</p>
                     <a href="#" class="btn btn-primary">See Profile</a>
                     </div>
                </div>
            </div>
            </div>
        </div>
    </div>
</section>

<section class="my-5">
    <div class="py-5">
        <h3 class="text-center">Gallery</h3>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-12">
                <img src="images/dj5.jpg" class="img-fluid pb-3" height="100%" width="100%">
            </div>
             <div class="col-lg-4 col-md-4 col-12">
                <img src="images/dj6.jpg" class="img-fluid pb-3" height="100%" width="100%">
            </div>
            <div class="col-lg-4 col-md-4 col-12">
                <img src="images/dj7.jpg" class="img-fluid pb-3" height="100%" width="100%">
            </div>
            <div class="col-lg-4 col-md-4 col-12">
                <img src="images/dj8.jpeg" class="img-fluid pb-3" height="100%" width="100%">
            </div>
            <div class="col-lg-4 col-md-4 col-12">
                <img src="images/dj9.jpeg" class="img-fluid pb-3" height="100%" width="100%">
            </div>
            <div class="col-lg-4 col-md-4 col-12">
                <img src="images/dj10.jpeg" class="img-fluid pb-3" height="100%" width="100%">
            </div>
            <div class="col-lg-4 col-md-4 col-12">
                <img src="images/dj11.jpeg" class="img-fluid pb-3" height="100%" width="100%">
            </div>
            <div class="col-lg-4 col-md-4 col-12">
                <img src="images/dj12.jpeg" class="img-fluid pb-3" height="100%" width="100%">
            </div>
            <div class="col-lg-4 col-md-4 col-12">
                <img src="images/dj13.jpeg" class="img-fluid pb-3" height="100%" width="100%">
            </div>
        </div>
    </div>
</section>

<section class="my-5">
    <div class="py-5">
        <h3 class="text-center">Contact Us</h3>
    </div>
    <div class="w-50 m-auto">
      <form action="userinfo.php" method="post">
        <div class="form-group">
          <label>Username</label>
          <input type="text" name="user" autocomplete="off" class="form-control">
        </div>
        <div class="form-group">
          <label>Email</label>
          <input type="text" name="email" autocomplete="off" class="form-control">
        </div>
        <div class="form-group">
          <label>Mobile</label>
          <input type="text" name="mobile" autocomplete="off" class="form-control">
        </div>
        <div class="form-group">
          <label>Comment</label>
          <textarea name="comment" autocomplete="off" class="form-control">
          </textarea>
        </div>
        <button type="submit" class="btn btn-success">Submit</button>
      </form>
    </div>
</section>

<footer>
  <p class="p-3 bg-dark text-white text-center">Powered :- @mr_urmish_rakholiya</p>
</footer>


<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>