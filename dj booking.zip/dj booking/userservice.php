<?php
$con = mysqli_connect('localhost','root');
if($con){
    echo "Connection Successful";
}else{
    "no connection";
}
mysqli_select_db($con, 'dj booking');


$location = $_POST['location'];
$destination = $_POST['destination'];
$people = $_POST['people'];


$query = "insert into userservicedata (location, destination, people)
values ('$location', '$destination', '$people') ";


mysqli_query($con,$query );


header('location:successfull.php');
?>