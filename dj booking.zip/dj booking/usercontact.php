<?php
$con = mysqli_connect('localhost','root');
if($con){
    echo "Connection Successful";
}else{
    "no connection";
}
mysqli_select_db($con, 'dj booking');


$usernumber = $_POST['usernumber'];
$userlocation = $_POST['userlocation'];
$time = $_POST['time'];


$query = "insert into usercontactdata (usernumber, userlocation, time)
values ('$usernumber', '$userlocation', '$time') ";


mysqli_query($con,$query );


header('location:successfull.php');
?>